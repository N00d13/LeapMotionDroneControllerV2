require 'yaml'

_ = YAML.load("---")
